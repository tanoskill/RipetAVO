<?php
  session_start();
  session_destroy();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style/style.css" />
    <link rel="icon" href="img/icon.svg" type="image/svg">
    <title>User - Login</title>
  </head>
  <body>

    <?php //include 'connection.php'; ?>

    <div class="container">
      <div class="forms-container">
        <div class="signin-signup">
          <form action="visualizza.php" method="post" class="sign-in-form">
            <h2 class="title">Accedi</h2>
            <div class="input-field">
              <i class="fas fa-user"></i>
              <input type="text"
                     name="Username"
                     placeholder="Username"
                     required />
            </div>
            <div class="input-field">
              <i class="fas fa-lock"></i>
              <input type="password"
                     name="Password"
                     placeholder="Password"
                     required />
            </div>
            <input type="submit" value="Login" class="btn solid" />
          </form>
          <h2 class="title signup">Registrati</h2>
          <form action="visualizza.php" method="post" class="sign-up-form">
            <br><br><br><br><br><br>
            <br><br><br><br><br><br>
            <br><br><br><br><br><br>
            <br><br><br><br><br><br>
            <br><br><br><br><br>
            <div class="input-field">
              <i class="fas fa-user"></i>
              <input type="text"
                     name="Username"
                     placeholder="Username"
                     required />
            </div>


            <div class="input-field">
              <i class="fas fa-envelope" ajax1></i>
              <input type="email"
                     name="Email"
                     placeholder="Email"
                     onkeyup="check(this.value)"
                     required
                     ajax />
            </div>

            <div class="input-field">
              <i class="fas fa-lock"></i>
              <input type="password"
                     name="Password"
                     placeholder="Password"
                     required />
            </div>
            <div class="input-field">
              <i class="fas fa-calendar"></i>
              <input type="text"
                     name="Data_di_nascita"
                     placeholder="Data di nascita"
                     onfocus="(this.type='date')"
                     onblur="(this.type='text')"
                     required />
            </div>
            <div class="input-field">
              <i class="fas fa-map-marked-alt"></i>
              <select name="Luogo_di_nascita" required >
                <option value="">Luogo di nascita</option>
                <?php/*
                  $sql = "SELECT * FROM paesi";
                  $result = $conn->query($sql) or die($conn->error);
                  $stati = array();
                  while($row = $result -> fetch_assoc()){
                    echo '<option value="',$row["id"],'"> ',$row["nazione"],'</option>';
            			}*/
                ?>
              </select>
            </div>
            <div class="input-field">
              <i class="fas fa-pager"></i>
              <input type="url"
                     name="Sito_internet"
                     placeholder="Sito internet"
                     required />
            </div>
            <div class="input-field" id="colore">
              <i class="fas fa-palette" id="colore2"></i>
              <input type="color"
                     name="Colore"
                     id="colorId"
                     required />
            </div>
            <div class="input-field textdiv">
              <i class="fas fa-comments"></i>
              <textarea name="Testo"
                        rows="4"
                        cols="25"
                        placeholder="Scrivi qualcosa..."></textarea>
            </div>
            <div class="input-gender">
              <?php/*
                $sesso = array(
                  "M" => "Maschio",
                  "F" => "Femmina"
                );

                foreach ($sesso as $s => $s_value) {
                  echo '<div class="radio-label">';
                  echo '<input type="radio" name="Genere" value="',$s,'"required />';
                  echo '<label for ="',$s,'" > ',$s_value,'</label>';
                  echo '</div>';
                }
*/
              ?>
            </div>
            <div class="input-terms">
              <div class="terms-title">
                <div class="line"></div>
                <h2>Accetta i termini</h2>
                <div class="line"></div>
              </div>
              <div class="terms">
                <?php/*

                    $sql = "SELECT * FROM termini";
                    $result = $conn->query($sql) or die($conn->error);
                    $checkbox = array();
                    while($row = $result -> fetch_assoc()){
                      echo '<input type="checkbox" name=',$row["id"],'>';
                      echo '<label for ="',$row["id"],'"> Accetta ',$row["autorizzazione"],'</label> <br />';
                    }*/
                ?>
              </div>
            </div>
            <input type="submit" class="btn" id="signup"  value="Sign up" />
          </form>
        </div>
      </div>

      <div class="panels-container">
        <div class="panel left-panel">
          <div class="content">
            <h3>Non possiedi un account?</h3>
            <p>
              Se ancora non possiedi un account puoi crearlo subito compilando il form che ti verrà
              sottoposto nella pagina seguente!
            </p>
            <button class="btn transparent" id="sign-up-btn">
              SIGN UP
            </button>
          </div>
          <img src="img/log.svg" class="image sx" alt="" />
        </div>
        <div class="panel right-panel">
          <div class="content">
            <h3>Hai già un account?</h3>
            <p>
              Se possiedi già un account ti basterà inserire Username e Password nella pagina successiva!
            </p>
            <button class="btn transparent" id="sign-in-btn">
              Sign in
            </button>
          </div>
          <img src="img/register.svg" class="image" alt="" />
        </div>
      </div>
    </div>

    <script src = "js/script.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>
