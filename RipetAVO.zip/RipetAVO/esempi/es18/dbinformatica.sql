-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Apr 22, 2021 alle 23:37
-- Versione del server: 10.4.14-MariaDB
-- Versione PHP: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbinformatica`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `paesi`
--

CREATE TABLE `paesi` (
  `id` int(11) NOT NULL,
  `nazione` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `paesi`
--

INSERT INTO `paesi` (`id`, `nazione`) VALUES
(1, 'Italia\r\n'),
(2, 'Germania'),
(3, 'Francia'),
(4, 'Spagna'),
(5, 'Portogallo'),
(6, 'Belgio'),
(7, 'Olanda'),
(8, 'Svizzera'),
(9, 'Austria'),
(10, 'Lussemburgo');

-- --------------------------------------------------------

--
-- Struttura della tabella `termini`
--

CREATE TABLE `termini` (
  `id` int(11) NOT NULL,
  `autorizzazione` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `termini`
--

INSERT INTO `termini` (`id`, `autorizzazione`) VALUES
(1, 'i cookies'),
(2, 'la privacy'),
(3, 'le notifiche'),
(4, 'il trattamento dati');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `data_di_nascita` date NOT NULL,
  `luogo_di_nascita` int(11) NOT NULL,
  `sito_internet` varchar(255) NOT NULL,
  `colore` varchar(7) NOT NULL,
  `testo` text NOT NULL,
  `genere` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`id`, `username`, `email`, `password`, `data_di_nascita`, `luogo_di_nascita`, `sito_internet`, `colore`, `testo`, `genere`) VALUES
(166, 'lorenzo', 'gamba.lorenzo2002@gmail.com', '3334703c735bd09f54c377b4dfaac1c3', '2002-07-31', 1, 'http://localhost/esercizi/es13BIS/index.php', '#777777', 'ciao', 'M'),
(167, 'lorenzo', 'gamba.lorenzo2002@gmail.com', '3334703c735bd09f54c377b4dfaac1c3', '2002-07-31', 1, 'http://localhost/esercizi/es13BIS/index.php', '#777777', 'ciao', 'M'),
(168, 'qwe', 'gamba.lorenzo2002@gmail.com', '76d80224611fc919a5d54f0ff9fba446', '2000-07-31', 1, 'http://localhost/esercizi/es13BIS/index.php', '#777777', 'qwe', 'M'),
(172, 'qwe', 'qwe@qwe.qwe', '76d80224611fc919a5d54f0ff9fba446', '2002-01-01', 1, 'http://localhost/esercizi/es13BIS/index.php', '#777777', 'qwe', 'M'),
(173, 'qwe', 'qwe@qwe.qwe', '76d80224611fc919a5d54f0ff9fba446', '2002-01-01', 1, 'http://localhost/esercizi/es13BIS/index.php', '#777777', 'qwe', 'M'),
(174, 'qwe', 'qwe@qwe.qwe', '76d80224611fc919a5d54f0ff9fba446', '2002-01-01', 1, 'http://localhost/esercizi/es13BIS/index.php', '#777777', 'qwe', 'M'),
(175, 'qwe', 'qwe@qwe.qwe', '76d80224611fc919a5d54f0ff9fba446', '2002-01-01', 1, 'http://localhost/esercizi/es13BIS/index.php', '#777777', 'qwe', 'M'),
(176, 'qwe', 'qwe@qwe.qwe', '76d80224611fc919a5d54f0ff9fba446', '2002-01-01', 1, 'http://localhost/esercizi/es13BIS/index.php', '#777777', 'qwe', 'M'),
(179, 'qwe', 'qwe@qwe.qwe', '76d80224611fc919a5d54f0ff9fba446', '2002-01-01', 1, 'http://localhost/esercizi/es13BIS/index.php', '#777777', 'qwe', 'M');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti_termini`
--

CREATE TABLE `utenti_termini` (
  `id_utente` int(11) NOT NULL,
  `id_termine` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `utenti_termini`
--

INSERT INTO `utenti_termini` (`id_utente`, `id_termine`) VALUES
(166, 1),
(166, 2),
(168, 1),
(168, 2),
(168, 3),
(168, 4),
(172, 1),
(172, 2),
(173, 1),
(173, 2),
(174, 1),
(174, 2),
(175, 1),
(175, 2),
(176, 1),
(176, 2),
(179, 1),
(179, 2);

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `paesi`
--
ALTER TABLE `paesi`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `termini`
--
ALTER TABLE `termini`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`id`),
  ADD KEY `luogo_di_nascita` (`luogo_di_nascita`);

--
-- Indici per le tabelle `utenti_termini`
--
ALTER TABLE `utenti_termini`
  ADD KEY `id_utente` (`id_utente`),
  ADD KEY `id_termine` (`id_termine`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `paesi`
--
ALTER TABLE `paesi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT per la tabella `termini`
--
ALTER TABLE `termini`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=184;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `utenti`
--
ALTER TABLE `utenti`
  ADD CONSTRAINT `utenti_ibfk_1` FOREIGN KEY (`luogo_di_nascita`) REFERENCES `paesi` (`id`);

--
-- Limiti per la tabella `utenti_termini`
--
ALTER TABLE `utenti_termini`
  ADD CONSTRAINT `id_termine` FOREIGN KEY (`id_termine`) REFERENCES `termini` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `id_utente` FOREIGN KEY (`id_utente`) REFERENCES `utenti` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `utenti_termini_ibfk_1` FOREIGN KEY (`id_utente`) REFERENCES `utenti` (`id`),
  ADD CONSTRAINT `utenti_termini_ibfk_2` FOREIGN KEY (`id_termine`) REFERENCES `termini` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
