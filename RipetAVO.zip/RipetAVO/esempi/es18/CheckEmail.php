<?php
    include 'connection.php';

    $email = $_GET['q'];
    $sql="SELECT * FROM utenti  WHERE email = '".$email."' ";
    $result = $conn->query($sql) or die($conn->error);
    $flag = false;

    if($row = $result -> fetch_assoc() > 0){
        echo "true";
    }else{
        echo "false";
    }
    mysqli_close($conn);
?>
