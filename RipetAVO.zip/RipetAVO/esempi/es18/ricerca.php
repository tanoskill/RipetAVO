<?php
  session_start();

  if (empty($_SESSION)) {
    header("location: index.php");
  }else{
    if ($_SESSION["lastPV"] != "ricerca" || !isset($_SESSION["lastPV"])) {
      $_SESSION["timeOut"] = time();
      $_SESSION["lastPV"] = "ricerca";
    }
  }
  
  if (isset($_SESSION['timeOut']))
  {
    $time = $_SESSION['timeOut'];
    if (time() > ($time + 3600)){
    session_unset();
    session_destroy();
    header("Location: index.php");
    }
  }

  if (!isset($_COOKIE["theme"])) {
    $name = "theme";
    $theme = "light";
    setcookie($name,$theme, time() + (86400 * 30), "/");
  }

?>

<!DOCTYPE html>
<html lang="en" <?php echo "data-theme=".$_COOKIE["theme"]; ?>>
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style/style2.css" />
        <link rel="icon" href="img/icon.svg" type="image/svg">
    <title>Ricerca</title>
  </head>
  <body class="visualizza">
  <body>

    <?php include 'connection.php'
    ?>

    <div class="background"></div>

    <div class="header">
      <div class="header_bar" btnM onclick="toggleMenu()">
        <span></span>
        <span></span>
        <span></span>
        <span></span>
      </div>
      <div class="header_menu" menu>
        <ul>
          <li><a href="index.php"><i class="fas fa-user"></i> Log out</a></li>
          <li><a href="visualizza.php"><i class="fas fa-list"></i> Visualizza utenti</a></li>
          <li><a href="elimina.php"><i class="fas fa-trash"></i> Elimina Utenti</a></li>
          <li><a href="visualizza.php"><i class="fas fa-search"></i> Ricerca utenti</a></li>
        </ul>
      </div>
    </div>

    <div class="list2">
        <table class="custom-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Data di nascita</th>
                    <th>Luogo di nascita</th>
                    <th>Sito internet</th>
                    <th>Colore</th>
                    <th>Testo</th>
                    <th>Genere</th>
                    <th>Accetta</th>
                </tr>
            </thead>
            <tbody>

              <?php
                switch ($_REQUEST["Campo"]) {
                  case '1': $campo = "id"; break;
                  case '2': $campo = "username"; break;
                  case '3': $campo = "email"; break;

                }

                if (empty($_REQUEST["ricerca"])) {
                  $sql = "SELECT u.id, u.username, u.email, u.data_di_nascita, p.nazione, u.sito_internet, u.colore, u.testo, u.genere, GROUP_CONCAT(t.autorizzazione SEPARATOR '<br>') as consensi ";
                  $sql .= "FROM utenti AS u ";
                  $sql .= "LEFT OUTER JOIN paesi AS p ";
                  $sql .= "ON u.luogo_di_nascita = p.id ";
                  $sql .= "LEFT OUTER JOIN utenti_termini AS ut ";
                  $sql .= "ON u.id = ut.id_utente ";
                  $sql .= "LEFT OUTER JOIN termini AS t ";
                  $sql .= "ON ut.id_termine = t.id ";
                  $sql .= "GROUP BY u.id;";
                } else {
                  $sql = "SELECT u.id, u.username, u.email, u.data_di_nascita, p.nazione, u.sito_internet, u.colore, u.testo, u.genere, GROUP_CONCAT(t.autorizzazione SEPARATOR '<br>') as consensi ";
                  $sql .= "FROM utenti AS u ";
                  $sql .= "LEFT OUTER JOIN paesi AS p ";
                  $sql .= "ON u.luogo_di_nascita = p.id ";
                  $sql .= "LEFT OUTER JOIN utenti_termini AS ut ";
                  $sql .= "ON u.id = ut.id_utente ";
                  $sql .= "LEFT OUTER JOIN termini AS t ";
                  $sql .= "ON ut.id_termine = t.id ";
                  $sql .= "WHERE u.".$campo." = \"".$_REQUEST["ricerca"]."\" ";
                  $sql .= "GROUP BY u.id;";
                }

                $result = $conn->query($sql) or die($conn->error);
                while($row = $result -> fetch_assoc()){
                  echo "<tr>";
                  echo "<td>",$row["id"],"</td>";
                  echo "<td>",$row["username"],"</td>";
                  echo "<td>",$row["email"],"</td>";
                  echo "<td>",$row["data_di_nascita"],"</td>";
                  echo "<td>",$row["nazione"],"</td>";
                  echo "<td>",$row["sito_internet"],"</td>";
                  echo "<td><div style=\"background-color:",$row["colore"],"; width: 16px; height: 16px; border-radius: 8px; margin: auto\"></div>";
                  echo "<td>",$row["testo"],"</td>";
                  if ($row["genere"] == "M") {
                    echo "<td>Maschio</td>";
                  } else {
                    echo "<td>Femmina</td>";
                  }
                  echo "<td>",$row["consensi"],"</td>";
                }
              ?>
            </tbody>
        </table>
    </div>

    <label class="switch">
      <input type="checkbox" id="toggleTheme" onclick="changeTheme()" themeBTN <?php if ($_COOKIE["theme"] == "dark") { echo "checked"; } ?>>
      <span class="slider round"></span>
    </label>

   <script>
      function changeTheme(){
        let btn = document.getElementById('toggleTheme');
        if(btn.checked == true) {
          document.cookie = "theme=dark";
          location.reload();
        } else {
          document.cookie = "theme=light";
          location.reload();
        }
      }

      function toggleMenu(){
            let menu = document.querySelector("[menu]");
            let btnM = document.querySelector("[btnM]");
            if(menu.classList.contains("open"))
            { menu.classList.remove("open"); }
            else
            { menu.classList.add("open"); }

            if(btnM.classList.contains("open"))
            { btnM.classList.remove("open"); }
            else
            { btnM.classList.add("open"); }
          }
    </script>
  </body>
</html>
