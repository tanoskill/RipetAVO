const sign_in_btn = document.querySelector("#sign-in-btn");
const sign_up_btn = document.querySelector("#sign-up-btn");
const container = document.querySelector(".container");

sign_up_btn.addEventListener("click", () => {
  container.classList.add("sign-up-mode");
});

sign_in_btn.addEventListener("click", () => {
  container.classList.remove("sign-up-mode");
});

var colorId;
var defaultColor = "#777777";

window.addEventListener("load", startup, false);
function startup() {
  colorId = document.querySelector("#colorId");
  colorId.value = defaultColor;
  colorId.addEventListener("input", updateFirst, false);
  colorId.select();
}

function updateFirst(event) {
  var div = document.querySelector("#colore");
  if (div) {
    div.style.background = event.target.value;
  }
}
