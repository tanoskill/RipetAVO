function check(Email){
  if (Email == "") {
    document.getElementById("signup").style.BorderColor = "#5995fd";
    document.getElementById("signup").setAttribute('value', 'Sign up');
    document.getElementById("signup").style.background = "#5995fd";
    document.getElementById("signup").type = "input";
    return;
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200){
        if(xmlhttp.responseText == "true"){
            console.log(xmlhttp.responseText);
            document.getElementById("signup").style.BorderColor = "#ff0000";
            document.getElementById("signup").setAttribute('value', 'Errore');
            document.getElementById("signup").style.background = "#ff0000";
            document.querySelector("[ajax]").value = "";
            document.querySelector("[ajax1]").style.color = "#ff0000";
          }else{
            document.getElementById("signup").style.BorderColor = "#5995fd";
            document.getElementById("signup").setAttribute('value', 'Sign up');
            document.getElementById("signup").style.background = "#5995fd";
            document.querySelector("[ajax1]").style.color = "#acacac";
          }
        }
      };
      xmlhttp.open("GET","CheckEmail.php?q="+Email,true);
      xmlhttp.send();
    }
  }
