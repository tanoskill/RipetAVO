<?php
session_start();
include 'session.php';
include "connection.php";

if (!empty($_REQUEST)) {
	switch ($_REQUEST["tipo"]) {
		case "registrazione": {
				$nomeProvv = str_replace("'", "\\'", $_REQUEST["nome"]);
				$cognomeProvv = str_replace("'", "\\'", $_REQUEST["cognome"]);
				$email = $_REQUEST["email"];
				$password = str_replace("'", "\\'", $_REQUEST["password"]);
				$classe = $_REQUEST["classe"];
				$indirizzo = $_REQUEST["indirizzo"];
				$passwordCRYPT = sha1($password);
				$anno = substr($classe, 0, 1);
				$sezione = substr($classe, 1, 1);

				$nome = ucfirst($nomeProvv);
				$cognome = ucfirst($cognomeProvv);

				mysqli_begin_transaction($conn);
				try{
					$sql = "INSERT INTO studenti (nome, cognome, email, password, anno, sezione, indirizzo)";
					$sql .= "VALUES ('$nome', '$cognome', '$email', '$passwordCRYPT', '$anno', '$sezione', '$indirizzo')";
					if ($conn->query($sql)) {
						$controllo = "Studente aggiunto correttamente";
						$last_id = $conn->insert_id;
						$_SESSION["id"] = $last_id;
						$_SESSION["nome"] = $nome;
						$_SESSION["cognome"] = $cognome;
						$_SESSION["email"] = $_REQUEST["email"];
						$_SESSION["anno"] = $anno;
						$_SESSION["sezione"] = $sezione;
						$_SESSION["indirizzo"] = $indirizzo;
					} else {
						$controllo = "Errore: " . $conn->error;
					}

					$checkalunno = 'SELECT * FROM alunni WHERE id_studente = ' . $_SESSION["id"];
					$result = $conn->query($checkalunno) or die($conn->error);
					$numero_righe = mysqli_num_rows($result);
					if ($numero_righe == 0) {
						$insertAlunni = 'INSERT INTO alunni (id_studente, ore_da_alunno) VALUES (' . $_SESSION["id"] . ', 0)';
						if ($conn->query($insertAlunni)) {
							$_SESSION["id_alunno"] = $conn->insert_id;
						} else {
							echo "Errore nell'inserimento dell'Alunno" . $conn->error . "\n";
						}
					} else {
						while ($row = $result->fetch_assoc()) {
							$_SESSION["id_alunno"] = $row["id"];
						}
					}
					mysqli_commit($conn);
				} catch (mysqli_sql_exception $exception) {
					mysqli_rollback($conn);
				}
				header('Location: home.php');

				// header('Location: insert.php');
			}
			break;
	}
} else {
	if (!isset($_SESSION["id"])) {
		header('Location: index.php');
	}
}
?>
<!DOCTYPE html>
<html lang="en" ?>

<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="style/insert.css">
	<link href='https://fonts.googleapis.com/css?family=Nunito:400,300' rel='stylesheet' type='text/css'>
	<script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
	<link rel="icon" href="images/icon_img.svg" type="image/svg">
	<title>RipetAVO</title>
</head>

<body>
	<div class="accept" div1>
		<h1 class="title1">Possibilità di ripassare e di ripetere...</h1>
		<p class="description1">
			L'Avogadro dà la possibilità agli alunni di tutte le classi e indirizzi di ripassare
			materie e argomenti poco chiari con lezioni pomeridiane. Saranno proprio i vostri compagni
			a rispiegarvi i concetti, mettendo a diposizione il loro tempo in cambio di crediti.
			Le lezioni sono di un'ora ciascuna ed è possibile scegliere il giorno e una delle tre
			fasce orarie: <br><span><br>15:00 - 16:00<br>16:00 - 17:00<br>17:00 - 18:00</span>
		</p>
		<button class="special" onclick="swap()">Accetta e continua</button>
	</div>

	<div class="container hide" div2>
		<div class="title">
			<h1 class="title2">Seleziona le materie che sei disposto ad insegnare</h1>
			<h3 class="description">Puoi anche non selezionare nulla nel caso<br>tu voglia solo ripassare.<br>Potrai modificare la tua scelta quando vorrai</h3>
			<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
				<path fill="#0066CC" fill-opacity="1" d="M0,224L40,202.7C80,181,160,139,240,122.7C320,107,400,117,480,144C560,171,640,213,720,229.3C800,245,880,235,960,213.3C1040,192,1120,160,1200,154.7C1280,149,1360,171,1400,181.3L1440,192L1440,0L1400,0C1360,0,1280,0,1200,0C1120,0,1040,0,960,0C880,0,800,0,720,0C640,0,560,0,480,0C400,0,320,0,240,0C160,0,80,0,40,0L0,0Z"></path>
			</svg>
		</div>
		<div class="form">
			<form action="home.php" method="post" autocomplete="off">
				<input type="hidden" value="materie" name="tipo" required>
				<fieldset>
					<legend>Materie</legend>
					<table border="0">
						<?php
						$queryMaterie = 'SELECT m.nome, m.id';
						$queryMaterie .= ' FROM materie as m';
						$queryMaterie .= ' INNER JOIN materie_indirizzo as mi';
						$queryMaterie .= ' ON m.id = mi.id_materia';
						$queryMaterie .= ' INNER JOIN indirizzi as i';
						$queryMaterie .= ' ON mi.id_indirizzo = i.id';
						$queryMaterie .= ' WHERE i.id = (SELECT studenti.indirizzo FROM studenti WHERE id = ' . $_SESSION["id"] . ')';
						$result1 = $conn->query($queryMaterie) or die($conn->error);

						while ($materia = $result1->fetch_assoc()) {
							echo '<tr>';
							echo '<td>';
							echo '<input type="checkbox" id="cb" name=' . $materia["id"] . '>';
							echo '</td>';
							echo '<td>';
							echo '<label class="bianco" for="' . $materia["id"] . '">' . $materia["nome"] . '</label><br>';
							echo '</td>';
							echo '</tr>';
						}
						?>
					</table>
				</fieldset>
				<div class="buttonHolder">
					<button type="reset" onclick="swap()" class="special2"><i class="fas fa-angle-double-left"></i></button>
					<button type="submit">Sign Up</button>
				</div>
			</form>
		</div>
	</div>
	<script src="script/main.js"></script>
</body>

</html>