<?php
$host  = "localhost";
$username = "root";
$password = "";
$db_name = "ripetizioni_avo";

$conn = new mysqli($host, $username, $password, $db_name);
if($conn -> connect_errno)
{
  echo "Impossibile connettersi al server: " . $conn -> connect_errno . "\n";
  exit;
}
?>
