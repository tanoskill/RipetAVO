<?php
session_start();
include "session.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>RipetAVO</title>
    <link rel="icon" href="images/icon_img.svg" type="image/svg">
    <link rel="stylesheet" href="style/style1.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.14.0/css/all.css" integrity="sha384-HzLeBuhoNPvSl5KYnjx0BT+WB0QEEqLprO+NBkkk5gbc67FTaL7XIGa2w1L0Xbgc" crossorigin="anonymous" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <link rel="icon" href="images/icon_img.svg" type="image/svg">
    <title>RipetAVO</title>
</head>

<body>
    <?php
    include "connection.php";

    if (!empty($_REQUEST)) {
        switch ($_REQUEST["tipo"]) {
                // ------------------------------------------ Arrivando dalla pagina di insert
            case "materie": {
                    mysqli_begin_transaction($conn);
                    try {
                        // ---------------------------------- insert in tabella insegnanti
                        if (sizeof($_REQUEST) > 1) {
                            $checkInsegnante = 'SELECT * FROM insegnanti WHERE id_studente = ' . $_SESSION["id"];
                            $result = $conn->query($checkInsegnante) or die($conn->error);
                            $numero_righe = mysqli_num_rows($result);
                            if ($numero_righe == 0) {
                                $insertInsegnanti = 'INSERT INTO insegnanti (id_studente, ore_da_insegnante, crediti) VALUES (' . $_SESSION["id"] . ', 0, 0)';
                                if ($conn->query($insertInsegnanti)) {
                                    $_SESSION["id_insegnante"] = $conn->insert_id;
                                } else {
                                    echo "Errore nell'inserimento dell'Insegnante" . $conn->error . "\n";
                                }
                            } else {
                                while ($row = $result->fetch_assoc()) {
                                    $_SESSION["id_insegnante"] = $row["id"];
                                }
                            }

                            // ---------------------------------- insert in tabella insegnanti_materie
                            $checkMaterie = 'SELECT m.id';
                            $checkMaterie .= ' FROM materie as m';
                            $checkMaterie .= ' INNER JOIN insegnanti_materie as im';
                            $checkMaterie .= ' ON m.id = im.id_materia';
                            $checkMaterie .= ' WHERE im.id_insegnante = ' . $_SESSION["id_insegnante"];
                            $resultMaterie = $conn->query($checkMaterie) or die($conn->error);
                            $numero_righe = mysqli_num_rows($result);
                            if ($numero_righe == 0) {
                                $selectMaterie = "SELECT id ";
                                $selectMaterie .= "FROM materie";
                                $result = $conn->query($selectMaterie) or die($conn->error);
                                while ($row = $result->fetch_assoc()) {
                                    if (isset($_REQUEST[$row["id"]])) {
                                        $insertMaterie = "INSERT INTO insegnanti_materie (id_insegnante, id_materia)";
                                        $insertMaterie .= "VALUES (" . $_SESSION["id_insegnante"] . "," . $row["id"] . ")";
                                        if ($conn->query($insertMaterie)) {
                                        } else {
                                            echo "Errore nell'inserimento" . $conn->error . "\n";
                                        }
                                    }
                                }
                            } else {
                                $selectMaterie = "SELECT id ";
                                $selectMaterie .= "FROM materie";
                                $result = $conn->query($selectMaterie) or die($conn->error);
                                while ($row1 = $result->fetch_assoc()) {
                                    if (isset($_REQUEST[$row1["id"]])) {
                                        $checkExistance = false;
                                        while ($row = $resultMaterie->fetch_assoc()) {
                                            if ($row1["id"] == $row["id"]) {
                                                $checkExistance = true;
                                            }
                                        }
                                        if (!$checkExistance) {
                                            $insertMaterie = "INSERT INTO insegnanti_materie (id_insegnante, id_materia)";
                                            $insertMaterie .= "VALUES (" . $_SESSION["id_insegnante"] . "," . $row1["id"] . ")";
                                            if ($conn->query($insertMaterie)) {
                                            } else {
                                                echo "Errore nell'inserimento" . $conn->error . "\n";
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        mysqli_commit($conn);
                    } catch (mysqli_sql_exception $exception) {
                        mysqli_rollback($conn);
                    }
                    header('Location: home.php');
                }
                break;

                // ------------------------------------------ Arrivando dalla pagina home quando si prenota una lezione
            case "prenotazione": {
                    $selectIdMateria = 'SELECT materie.id FROM materie WHERE materie.nome ="' . $_REQUEST["materia"] . '"';
                    $result = $conn->query($selectIdMateria) or die($conn->error);
                    while ($row = $result->fetch_assoc()) {
                        $idmat = $row["id"];
                    }

                    mysqli_begin_transaction($conn);
                    try {
                        $checkDisponibilita = 'SELECT * FROM prenotazioni';
                        $checkDisponibilita .= ' WHERE id_insegnante = ' . $_REQUEST["insegnante"];
                        $checkDisponibilita .= ' AND data = "' . $_REQUEST["data"] . '"';
                        $checkDisponibilita .= ' AND orario = "' . $_REQUEST["ora"] . ':00"';
                        $result = $conn->query($checkDisponibilita) or die($conn->error);
                        $numero_righe = mysqli_num_rows($result);
                        if ($numero_righe == 0) {
                            $insertPrenotazione = 'INSERT INTO prenotazioni (id_insegnante, id_alunno, id_materia, data, orario, durata)';
                            $insertPrenotazione .= 'VALUES (' . $_REQUEST["insegnante"] . ',' . $_SESSION["id_alunno"] . ',' . $idmat . ',"' . $_REQUEST["data"] . '","' . $_REQUEST["ora"] . ':00",1)';
                            if ($conn->query($insertPrenotazione)) {
                            } else {
                                echo "Errore nell'inserimento" . $conn->error . "\n";
                            }
                        } else {
                            echo '<script language="javascript">';
                            echo 'alert("Insegnante non disponibile: cambia data/orario")';
                            echo '</script>';
                        }

                        mysqli_commit($conn);
                    } catch (mysqli_sql_exception $exception) {
                        mysqli_rollback($conn);
                    }
                    header("Location: home.php");
                }
                break;

                // ------------------------------------------ Arrivando dalla pagina home quando si elimina una lezione
            case "elimina": {
                    $deletePrenotazioni = 'DELETE FROM prenotazioni WHERE prenotazioni.id = ' . $_REQUEST["id"];
                    if ($conn->query($deletePrenotazioni)) {
                    } else {
                        echo "Errore nella cancellazione della prenotazione" . $conn->error . "\n";
                    }
                    header("Location: home.php#services");
                }
                break;

                // ----------------------------------------- Arrivando dalla pagina index quando ci si logga
            case "login": {
                    $selectParams = 'SELECT * ';
                    $selectParams .= 'FROM studenti ';
                    $selectParams .= 'WHERE studenti.email = "' . $_REQUEST["email"] . '" AND studenti.password = "' . sha1($_REQUEST["password"]) . '"';
                    $result = $conn->query($selectParams) or die($conn->error);
                    $numero_righe = mysqli_num_rows($result);
                    if ($numero_righe > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $_SESSION["id"] = $row["id"];
                            $_SESSION["nome"] = $row["nome"];
                            $_SESSION["cognome"] = $row["cognome"];
                            $_SESSION["email"] = $row["email"];
                            $_SESSION["anno"] = $row["anno"];
                            $_SESSION["sezione"] = $row["sezione"];
                            $_SESSION["indirizzo"] = $row["indirizzo"];
                        }

                        $selectIdAlunno = 'SELECT * FROM alunni WHERE id_studente = ' . $_SESSION["id"];
                        $result = $conn->query($selectIdAlunno) or die($conn->error);
                        $numero_righe = mysqli_num_rows($result);
                        if ($numero_righe > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $_SESSION["id_alunno"] = $row["id"];
                                $oreAlunno = $row["ore_da_alunno"];
                            }
                        }

                        $selectIdInsegnante = 'SELECT * FROM insegnanti WHERE id_studente = ' . $_SESSION["id"];
                        $result = $conn->query($selectIdInsegnante) or die($conn->error);
                        $numero_righe = mysqli_num_rows($result);
                        if ($numero_righe > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $_SESSION["id_insegnante"] = $row["id"];
                                $oreInsegnante = $row["ore_da_insegnante"];
                            }
                        }

                        $dataOdierna = date("Y-m-d");

                        $selectPrenotazioniAlunno = 'SELECT id FROM prenotazioni';
                        $selectPrenotazioniAlunno .= ' WHERE id_alunno = ' . $_SESSION["id_alunno"];
                        $selectPrenotazioniAlunno .= ' AND data < "' . $dataOdierna . '"';
                        $result = $conn->query($selectPrenotazioniAlunno) or die($conn->error);
                        $numero_righe = mysqli_num_rows($result);
                        if ($numero_righe > $oreAlunno) {
                            $updateOreAlunno = 'UPDATE alunni SET ore_da_alunno = ' . $numero_righe . ' WHERE alunni.id = ' . $_SESSION["id_alunno"];
                            $result = $conn->query($updateOreAlunno) or die($conn->error);
                        }

                        if (isset($_SESSION["id_insegnante"])) {
                            $selectPrenotazioniInsegnante = 'SELECT id FROM prenotazioni';
                            $selectPrenotazioniInsegnante .= ' WHERE id_insegnante = ' . $_SESSION["id_insegnante"];
                            $selectPrenotazioniInsegnante .= ' AND data < "' . $dataOdierna . '"';
                            $result = $conn->query($selectPrenotazioniInsegnante) or die($conn->error);
                            $numero_righe = mysqli_num_rows($result);
                            if ($numero_righe > $oreInsegnante) {
                                $oreDaInsegnante = 'UPDATE insegnanti SET ore_da_insegnante = ' . $numero_righe . ' WHERE insegnanti.id = ' . $_SESSION["id_insegnante"];
                                $result = $conn->query($oreDaInsegnante) or die($conn->error);
                            }
                        }
                    } else {
                        header('Location: index.php');
                    }
                    header('Location: home.php');
                }
                break;
        }
    } else {
        if (!isset($_SESSION["id"])) {
            header('Location: index.php');
        }
    }
    ?>
    <!-- Navbar Section -->
    <nav class="navbar">
        <div class="navbar__container">
            <a href="#home" id="navbar__logo">
                <img src="images/avatar_img.png" alt="">
                <p>RipetAVO</p>
            </a>
            <div class="navbar__toggle" id="mobile-menu">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </div>
            <ul class="navbar__menu">
                <li class="navbar__item">
                    <a href="#home" class="navbar__links" id="home-page">Home</a>
                </li>
                <li class="navbar__item">
                    <a href="#about" class="navbar__links" id="about-page">Ripetizioni</a>
                </li>
                <li class="navbar__item">
                    <a href="#services" class="navbar__links" id="services-page">Prenotazioni</a>
                </li>
                <li class="navbar__item">
                    <a href="#subjects" class="navbar__links" id="subjects-page">Materie</a>
                </li>
                <li class="navbar__btn">
                    <a href="index.php" class="button" id="signup">Log out</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero" id="home">
        <div class="hero__container">
            <h1 class="hero__heading">Benvenuto
                <?php
                echo $_SESSION["nome"];
                ?>
            </h1>
            <p class="hero__description">Visualizza o modifica il tuo profilo</p>
            <a href="user.php"><button class="main__btn">Clicca qui</button></a>
        </div>
    </div>

    <!-- About Section -->
    <div class="main" id="about">
        <div class="main__container">
            <div class="main__img--container">
                <div class="main__img--card">
                    <img src="images/ripetizioni_home.svg" alt="ripetizioni">
                </div>
            </div>
            <div class="main__content">
                <h1>devi ripassare?</h1>
                <h2>Prenota una ripetizione</h2>
                <p>Seleziona la materia, la data e l'orario.<br>La lezione durerà un'ora...</p>
                <div class='container'>
                    <form class='autocomplete-container' action="home.php" method="post" autocomplete="off">
                        <input type="hidden" value="prenotazione" name="tipo" required>
                        <div class='autocomplete'>
                            <input type="text" id="input" class='autocomplete-input' placeholder='Materia' name="materia" required>
                        </div>
                        <ul id='autocomplete-results' class='autocomplete-results hidden' role='listbox' aria-label='Materia'>
                        </ul>
                        <div class="date-time-teacher">
                            <?php
                            $giorno = date("d");
                            $mese = date("m");
                            $anno = date("Y");
                            $anno .= "-";
                            $anno .= $mese;
                            $anno .= "-";
                            $anno .= $giorno;

                            $date = date('d-m-Y', strtotime($anno));
                            ?>
                            <input type="text" name="data" placeholder="Data" onfocus="(this.type='date')" onblur="(this.type='date')" value="" class="data" min="<?php echo $anno; ?>" required>

                            <input type="text" name="ora" placeholder="Orario" onfocus="(this.type='time')" onblur="(this.type='text')" list="times" class="time" onchange="checkTime(this.value)" time required />
                            <datalist id="times">
                                <option>15:00</option>
                                <option>16:00</option>
                                <option>17:00</option>
                            </datalist>

                            <select name="insegnante" id="teacher" class="teacher" required>
                            </select>
                        </div>
                        <input type="submit" class="main__btn" value="Conferma" />
                    </form>
                </div>
            </div>
        </div>

        <!-- Services Section -->
        <div class="services" id="services">
            <h1>Le tue prenotazioni</h1>
            <h2 class="legend">
                <span class="blue_dot"></span> Alunno
                <span class="space"></span>
                <span class="yellow_dot"></span> Insegnante
            </h2>
            <div class="services__wrapper">
                <?php
                $dataOdierna = date("Y-m-d");

                $queryCard = 'SELECT prenotazioni.id, studenti.nome, studenti.cognome, prenotazioni.data, prenotazioni.orario, materie.nome as mnome';
                $queryCard .= ' FROM studenti INNER JOIN insegnanti';
                $queryCard .= ' ON studenti.id = insegnanti.id_studente';
                $queryCard .= ' INNER JOIN prenotazioni ON prenotazioni.id_insegnante = insegnanti.id';
                $queryCard .= ' INNER JOIN materie ON materie.id = prenotazioni.id_materia';
                $queryCard .= ' AND prenotazioni.id_alunno = ' . $_SESSION["id_alunno"];
                $queryCard .= ' AND prenotazioni.data >= "' . $dataOdierna . '"';
                $queryCard .= ' ORDER BY prenotazioni.data ASC';

                $resultCard = $conn->query($queryCard) or die($conn->error);
                $numero_righe = mysqli_num_rows($resultCard);
                $tot_righe = $numero_righe;
                if ($numero_righe != 0) {
                    while ($card = $resultCard->fetch_assoc()) {
                        $date = date('d-m-Y', strtotime($card["data"]));
                        $ora = substr($card["orario"], 0, 5);
                        $id = $card["id"];
                        echo '<div class="services__card">';
                        echo '<h3>Materia</h3>';
                        echo '<h2 class="card_text">' . $card["mnome"] . '</h2><br>';
                        echo '<h3>Insegnante</h3>';
                        echo '<h2 class="card_text1">' . $card["nome"] . ' ' . $card["cognome"] . '</h2><br>';
                        echo '<h3>Data e orario</h3>';
                        echo '<h2 class="card_text1">' . $date . '</h2>';
                        echo '<h2 class="card_text1">' . $ora . '</h2>';
                        echo '<form method="POST" action="" autocomplete="off">';
                        echo '<div class="services__btn">';
                        echo '<input type="hidden" name="tipo" value="elimina" />';
                        echo '<input type="hidden" name="id" value="' . $id . '"/>';
                        echo '<input type="submit" name="disdici" class="main__btn delete__card" value="Disdici"/>';
                        echo '</div>';
                        echo '</form>';
                        echo '</div>';
                    }
                }

                if (isset($_SESSION["id_insegnante"])) {
                    $queryCard = 'SELECT p.id, m.nome AS materia, s.nome, s.cognome, p.data, p.orario';
                    $queryCard .= ' FROM prenotazioni as p';
                    $queryCard .= ' INNER JOIN alunni as a';
                    $queryCard .= ' ON p.id_alunno = a.id';
                    $queryCard .= ' INNER JOIN studenti as s';
                    $queryCard .= ' ON a.id_studente = s.id';
                    $queryCard .= ' INNER JOIN materie as m';
                    $queryCard .= ' ON p.id_materia = m.id';
                    $queryCard .= ' WHERE p.id_insegnante = ' . $_SESSION["id_insegnante"];
                    $queryCard .= ' AND p.data >= "' . $dataOdierna . '"';
                    $queryCard .= ' ORDER BY p.data ASC';

                    $resultCard = $conn->query($queryCard) or die($conn->error);
                    $numero_righe = mysqli_num_rows($resultCard);
                    $tot_righe = $tot_righe + $numero_righe;
                    if ($numero_righe != 0) {
                        while ($card = $resultCard->fetch_assoc()) {
                            $date = date('d-m-Y', strtotime($card["data"]));
                            $ora = substr($card["orario"], 0, 5);
                            $id = $card["id"];
                            echo '<div class="services__card1">';
                            echo '<h3>Materia</h3>';
                            echo '<h2 class="card_text">' . $card["materia"] . '</h2><br>';
                            echo '<h3>Alunno</h3>';
                            echo '<h2 class="card_text1">' . $card["nome"] . ' ' . $card["cognome"] . '</h2><br>';
                            echo '<h3>Data e orario</h3>';
                            echo '<h2 class="card_text1">' . $date . '</h2>';
                            echo '<h2 class="card_text1">' . $ora . '</h2>';
                            echo '<form method="POST" action="" autocomplete="off">';
                            echo '<div class="services__btn">';
                            echo '<input type="hidden" name="tipo" value="elimina" />';
                            echo '<input type="hidden" name="id" value="' . $id . '"/>';
                            echo '<input type="submit" name="disdici" class="main__btn delete__card" value="Disdici"/>';
                            echo '</div>';
                            echo '</form>';
                            echo '</div>';
                        }
                    }
                }

                if ($tot_righe == 0) {
                    echo '<h2 class="no_pren">- Nessuna prenotazione attiva -</h2>';
                }
                ?>
            </div>
        </div>

        <!-- Features Section -->
        <div class="main" id="subjects">
            <div class="main__container">
                <div class="main__content">
                    <h1>Puoi dare ripetizioni?</h1>
                    <h2>Scegli le tue materie</h2>
                    <p>Verrai indirizzato alla scelta delle materie che puoi insegnare</p>
                    <a href="insert.php"><button class="main__btn">Scegli</button></a>

                </div>
                <div class="main__img--container">
                    <div class="main__img--card" id="card-2">
                        <img src="images/esame_home.svg" alt="esame">
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Section -->
        <div class="footer__container">
            <section class="social__media">
                <div class="social__media--wrap">
                    <div class="footer__logo">
                        <a href="/" id="footer__logo">RipetAVO</a>
                    </div>
                    <p class="website__rights">© RipetAVO 2021. Progetto maturità<br>ITIS A.Avogadro <br>Torino - Corso San Maurizio 8</p>
                    <div class="social__icons">
                        <a href="#" class="social__icon--link" target="_blank"><i class="fab fa-facebook"></i></a>
                        <a href="#" class="social__icon--link"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="social__icon--link"><i class="fab fa-youtube"></i></a>
                        <a href="#" class="social__icon--link"><i class="fab fa-linkedin"></i></a>
                        <a href="#" class="social__icon--link"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
            </section>
        </div>
    </div>
    <script src="script/main1.js"></script>
</body>

</html>

<script type="text/javascript">
    $(document).ready(function() {
        $("#input").keyup(function() {
            $.ajax({
                type: "POST",
                url: "ajax.php",
                data: 'keyword=' + $(this).val(),
                success: function(data) {
                    $("#autocomplete-results").show();
                    $("#autocomplete-results").html(data);
                    $("#input").css("background", "#FFF");
                }
            });
        });
    });

    function selectMaterie(val) {
        document.getElementById("input").value = val;
        $("#autocomplete-results").hide();
        selectIns(val);
    }

    function clear() {
        console.log("test");
        $("#autocomplete-results").hide();
        selectIns(document.getElementById("input").value);
    }

    function selectIns(val) {
        var nome = val;
        if (nome) {
            $.ajax({
                type: 'POST',
                url: 'ajax1.php',
                data: 'nome=' + nome,
                success: function(html) {
                    $('#teacher').html(html);
                }
            });
        } else {
            $('#teacher').html('<option value="">Insegnante</option>');
        }
    }
</script>