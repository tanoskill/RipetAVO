<?php
  session_start();
  session_destroy();
?>

<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/64d58efce2.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style/style.css" />
    <link rel="icon" href="images/icon_img.svg" type="image/svg">
    <title>RipetAVO</title>
  </head>

  <body>
    <?php
    include 'connection.php';/*
    if (sizeof($_REQUEST) > 1) {
      $to = $_REQUEST["email"];
      $subject = "Mail di verifica";
      $link = 'http://ripetavo.altervista.org/insert.php?';
      $link .= 'nome=' . $_REQUEST["nome"] . '&';
      $link .= 'cognome=' . $_REQUEST["cognome"] . '&';
      $link .= 'email=' . $_REQUEST["email"] . '&';
      $link .= 'password=' . $_REQUEST["password"] . '&';
      $link .= 'classe=' . $_REQUEST["classe"] . '&';
      $link .= 'indirizzo=' . $_REQUEST["indirizzo"];

      $message = '
      <html>
      <head>
        <title>Conferma Registrazione</title>
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <style>
          .titolo {
            font-size: 1.5rem;
            color: #fff;
            margin: 0px;
            margin-top: 5px;
          }
      
          td {
            padding-top: 0px;
          }
        </style>
      </head>
      
      <body>
        <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="border-collapse:collapse; margin:0" width="100%">
          <tbody>
            <tr bgcolor="#0066CC">
              <td bgcolor="#0066CC" style="text-align:center">
                <div style="height:32px"></div>
                <img alt="logo" height="32px" src="http://ripetavo.altervista.org/images/user.png" width="32px">
                <h2 class="titolo">RipetA</span>VO</h2>
                <div style="height:32px"></div>
              </td>
            </tr>
          </tbody>
        </table>
        <div style="padding: 0 32px; width:calc(100% - 64px)">
          <table align="center" cellpadding="0" cellspacing="0" role="presentation" style="background-color:#ffffff;border-collapse:collapse;max-width:528px;min-width:256px" width="100%">
            <tbody>
              <tr style="height:50px"></tr>
              <td style="color:#212121; font-size:20px; font-weight:700">Gentile ' . $_REQUEST["nome"] . ' ' . $_REQUEST["cognome"] . '</td>
              <tr style="height:5px"></tr>
              <td style="color:#212121; font-size:14px; font-weight:400">Ti sei appena registrato al sito
                <a href="http://ripetavo.altervista.org" style="color:4381B2; font-weight:400" target="_blank">RipetAVO</a>.
              </td>
              <tr style="height:18px"></tr>
              <table bgcolor="#fafafa" border="0" cellpadding="0" cellspacing="0" role="presentation" style="border:1px solid #f0f0f0;border-bottom:1px solid #c0c0c0;border-bottom-left-radius:3px;border-bottom-right-radius:3px;border-top:0" width="100%">
                <tbody>
                  <tr>
                    <td rowspan="3" width="24px"></td>
                    <td colspan="2" height="24px"></td>
                    <td rowspan="3" width="24px"></td>
                  </tr>
                  <tr>
                    <td style="padding-right:24px; padding-bottom:24px; padding-top:10px" valign="top" width="72px">
                      <div style="height:100px; width:72px"><img alt="logo" height="100px" src="http://ripetavo.altervista.org/images/avatar_img.png" width="72px"></div>
                    </td>
                    <td style="padding-top:0px">
                      <table cellpadding="0" cellspacing="0" role="presentation">
                        <tbody>
                          <tr>
                            <td style="color:#212121;font-size:14px;font-weight:400"></td>
                          </tr>
                          <tr height="0"></tr>
                          <tr>
                            <td style="color:#212121;font-size:20px;font-weight:500">Completa registrazione</td>
                          </tr>
                          <tr height="0"></tr>
                          <tr>
                            <td style="color:#737373;font-size:14px;font-weight:400">Clicca il bottone per proseguire</td>
                          </tr>
                          <tr height="16px"></tr>
                          <tr>
                            <td>
                              <table border="0" cellpadding="0" cellspacing="0" role="presentation" style="border-collapse:collapse;display:inline-block">
                                <tbody>
                                  <tr>
                                    <td><a href="' . $link . '" style="border-radius:3px;box-sizing:border-box;display:inline-block;font-size:14px;font-weight:700;height:32px;line-height:32px;padding:0 24px;text-align:center;text-decoration:none;text-transform:uppercase;vertical-align:middle;background-color:#1a73e8;color:#ffffff" target="_blank">CLICCA QUI</a>
                                    </td>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </td>
                  </tr>
                </tbody>
              </table>
              <tr style="height:15px"></tr>
              <tr style="color:#555; font-size:18px; font-weight:600; text-align:center;">I tuoi dati</tr>
              <tr style="color:#777;font-size:14px;font-weight:400;text-align:center">Email: ' . $_REQUEST["email"] . '</tr>
              <tr style="color:#777;font-size:14px;font-weight:400;text-align:center">Password: ' . $_REQUEST["password"] . '</tr>
              <tr style="color:#777;font-size:14px;font-weight:400;text-align:center">Sezione: ' . $_REQUEST["classe"] . ' ' . $_REQUEST["indirizzo"] . '</tr>
              <tr style="height:15px"></tr>
              <tr>
                <td>
                  <div style="border-top:1px solid #ccc;margin:0 auto"></div>
                  <div style="text-align:center;padding-top:24px;margin-bottom:8px">
                    <h2 style="font-size:1rem; color:#333; margin:0px">RipetA</span>VO</h2>
                  </div>
                  <div style="color:#a0a0a0;font-size:12px;font-weight:400;text-align:center;margin-bottom:30px">RipetAVO ©<br>ITIS A.Avogadro - Torino<br>Progetto maturità 2021</div>
                </td>
              </tr>
            </tbody>
          </table>
      
      </body>
      </html>';

      $headers[] = 'MIME-Version: 1.0';
      $headers[] = 'Content-type: text/html; charset=iso-8859-1';
      $headers[] = 'From: RipetAVO <ripetavo@gmail.com>';

      mail($to, $subject, $message, implode("\r\n", $headers));
    }*/
    ?>

    <div class="container">
      <div class="forms-container">
        <div class="signin-signup">

          <form action="home.php" method="post" class="sign-in-form" autocomplete="off">
            <input type="hidden" value="login" name="tipo" required> 
            <img class="logo-image" src="images/avatar_img.png" alt="logo">
            <h2 class="title">Ripet<span class="letter-spacing">A</span>VO</h2>

            <div class="input-field">
              <i class="fas fa-user"></i>
              <input type="email" placeholder="Email" name="email" required />
            </div>

            <div class="input-field">
              <i class="fas fa-lock"></i>
              <input type="password" placeholder="Password" name="password" required />
            </div>

            <input type="submit" value="Accedi" class="btn solid" />
          </form>

          <h2 class="title signup">Registrati</h2>
          <form action="insert.php" method="post" class="sign-up-form" autocomplete="off">
            <input type="hidden" value="registrazione" name="tipo" required> 

            <div class="input-field" nome1>
              <i class="fas fa-user" nome2></i>
              <input type="text" placeholder="Nome" name="nome" onchange="checkField('text '+this.value,'fa-user','[nome1]','[nome2]')" required />
            </div>

            <div class="input-field" cognome1>
              <i class="fas fa-id-card" cognome2></i>
              <input type="text" placeholder="Cognome" name="cognome" onchange="checkField('text '+this.value,'fa-id-card','[cognome1]','[cognome2]')" required />
            </div>

            <div class="input-field" mail1>
              <i class="fas fa-envelope" mail2></i>
              <input type="email" placeholder="Email" name="email" onchange="checkField('mail '+this.value,'fa-envelope','[mail1]','[mail2]')" required />
            </div>

            <div class="input-field" password1>
              <span class="tooltiptext2">Deve contenere almeno:<br>- 8 caratteri;<br>- 1 lettera maiuscola;<br>- 1 lettera minuscola;<br>- 1 carattere speciale;<br>- 1 numero.</span>
              <i class="fas fa-lock" password2></i>
              <input type="password" placeholder="Password" name="password" onkeyup="checkField('pass '+this.value,'fa-lock','[password1]','[password2]')" required />
            </div>

            <div class="input-field" classe1>
              <span class="tooltiptext">Esempio: 3C</span>
              <i class="fas fa-graduation-cap" classe2></i>
              <input type="text" placeholder="Classe" name="classe" maxlength="2" onchange="checkField('clss '+this.value,'fa-graduation-cap','[classe1]','[classe2]')" oninput="this.value = this.value.toUpperCase()" class required />
            </div>

            <div class="input-field">
              <i class="fas fa-cogs"></i>
              <select name="indirizzo" onchange="checkIndirizzo(this.value)" required>
                <option value="">Indirizzo</option>
                <?php
                $query = "SELECT * FROM indirizzi";
                $result = $conn->query($query) or die($conn->error);

                while ($row = $result->fetch_assoc()) {
                  echo "<option value='$row[id]'>$row[nome]</option>";
                }
                ?>
              </select>
            </div>

            <input type="submit" value="registrati" class="btn solid" id="button" onclick="sendmail()" />

          </form>
        </div>
      </div>

      <div class="panels-container">
        <div class="panel left-panel">
          <div class="content">
            <h3>Non possiedi un account?</h3>
            <p>
              Se ancora non possiedi un account puoi crearlo subito compilando il form che ti verrà
              sottoposto nella pagina seguente!
            </p>
            <button class="btn transparent" id="sign-up-btn">
              Sign up
            </button>
          </div>
          <img src="images/login_img.svg" class="image" alt="" />
        </div>
        <div class="panel right-panel">
          <div class="content">
            <h3>Hai già un account?</h3>
            <p>
              Se possiedi già un account ti basterà inserire Email e Password nella pagina successiva!
            </p>
            <button class="btn transparent" id="sign-in-btn">
              Sign in
            </button>
          </div>
          <img src="images/registrazione_img.svg" class="image" alt="" />
        </div>
      </div>
    </div>
    <script src="script/main.js"></script>
    
    <?php
       $conn->close();
    ?>
  </body>

</html>