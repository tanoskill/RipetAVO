<?php
session_start();
if (empty($_SESSION)) {
    header("location: index.php");
} else {
    include "session.php";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
    <link rel="stylesheet" href="style/style2.css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.14.0/css/all.css" integrity="sha384-HzLeBuhoNPvSl5KYnjx0BT+WB0QEEqLprO+NBkkk5gbc67FTaL7XIGa2w1L0Xbgc" crossorigin="anonymous" />
    <link rel="icon" href="images/icon_img.svg" type="image/svg">
    <title>RipetAVO</title>
</head>

<body>
    <?php include "connection.php"; ?>

    <?php
    if (!empty($_REQUEST)) {
        switch ($_REQUEST["tipo"]) {
            case "elimina": {
                    if (sizeof($_REQUEST) > 1) {
                        $deleteMaterie = 'DELETE FROM insegnanti_materie WHERE id_insegnante = ' . $_SESSION["id_insegnante"];
                        $deleteMaterie .= ' AND id_materia IN (';

                        $selectMaterie = 'SELECT m.id, m.nome';
                        $selectMaterie .= ' FROM materie as m';
                        $selectMaterie .= ' INNER JOIN insegnanti_materie as im';
                        $selectMaterie .= ' ON m.id = im.id_materia';
                        $selectMaterie .= ' INNER JOIN insegnanti as i';
                        $selectMaterie .= ' ON im.id_insegnante = i.id';
                        $selectMaterie .= ' WHERE i.id = ' . $_SESSION["id_insegnante"];
                        $result = $conn->query($selectMaterie) or die($conn->error);
                        while ($row = $result->fetch_assoc()) {
                            if (isset($_REQUEST[$row["id"]])) {
                                $deleteMaterie .= $row["id"] . ',';
                            }
                        }
                        $deleteMaterie1 = substr($deleteMaterie, 0, -1);
                        $deleteMaterie1 .= ')';

                        echo $deleteMaterie1;
                        $result = $conn->query($deleteMaterie1) or die($conn->error);
                    }
                }
                break;

            case "password": {
                    $newPass = sha1($_REQUEST["password"]);
                    $updatePass = 'UPDATE studenti SET password = "' . $newPass . '" WHERE studenti.id = ' . $_SESSION["id"];
                    $conn->query($updatePass) or die($conn->error);
                }
                break;
        }
        header("Location: user.php");
    } else {
        if (!isset($_SESSION["id"])) {
            header("Location: index.php");
        }
    }
    ?>

    <a href="home.php" class="back">
        <div class="backBtn">
            <i class="fas fa-chevron-left"></i>
        </div>
    </a>

    <div class="container">
        <div class="wrapper">
            <div class="left">
                <div class="user">
                    <?php
                    $firstNameLetter = substr($_SESSION["nome"], 0, 1);
                    $firstSurnameLetter = substr($_SESSION["cognome"], 0, 1);
                    echo '<h2 class="userLetters">' . $firstNameLetter . '' . $firstSurnameLetter . '</h2>';
                    ?>
                </div>
                <?php echo '<h4 class="nome_cognome">' . $_SESSION["nome"] . ' ' . $_SESSION["cognome"] . '</h4>'; ?>
                <form action="user.php" method="post" autocomplete="off">
                    <input type="hidden" name="tipo" value="password">
                    <input type="text" onfocus="(this.type='password'); (this.placeholder=''); swapButton();" onblur="(this.type='text'); (this.placeholder='Modifica password'); swapButton();" name="password" id="password" placeholder="Modifica password" class="cambia_pass" required>
                    <p class="snap" button>Premi Invio per confermare</p>
                </form>
                <?php
                if (isset($_SESSION["id_insegnante"])) {
                    echo '<p class="ruolo">Alunno e insegnante</p>';
                } else {
                    echo '<p class="ruolo">Alunno</p>';
                }
                ?>
            </div>
            <div class="right">
                <div class="info">
                    <h3>I TUOI DATI</h3>
                    <div class="info_data">
                        <div class="data">
                            <h4>Email</h4>
                            <?php echo '<p>' . $_SESSION["email"] . '</p>'; ?>
                        </div>
                        <div class="data">
                            <h4>Classe</h4>
                            <?php echo '<p>' . $_SESSION["anno"] . $_SESSION["sezione"] . ' ' . $_SESSION["indirizzo"] . '</p>'; ?>
                        </div>
                    </div>
                </div>

                <div class="projects">
                    <h3>RIPETIZIONI</h3>
                    <div class="projects_data">
                        <div class="data">
                            <h4>Ore da Alunno</h4>
                            <?php
                            $selectOreAlunno = 'SELECT ore_da_alunno AS ore FROM alunni WHERE id = ' . $_SESSION["id_alunno"];
                            $result = $conn->query($selectOreAlunno) or die($conn->error);
                            while ($row = $result->fetch_assoc()) {
                                echo '<p>Ore di ripetizioni: ' . $row["ore"];
                            }
                            ?>
                        </div>
                        <div class="data">
                            <h4>Ore da insegnante</h4>
                            <?php
                            if (isset($_SESSION["id_insegnante"])) {
                                $selectOreInsegnante = 'SELECT ore_da_insegnante AS ore FROM insegnanti WHERE id = ' . $_SESSION["id_insegnante"];
                                $result = $conn->query($selectOreInsegnante) or die($conn->error);
                                while ($row = $result->fetch_assoc()) {
                                    echo '<p>Ore di ripetizioni: ' . $row["ore"];
                                }
                            } else {
                                echo '<p> --- </p>';
                            }
                            ?>
                        </div>
                    </div>
                </div>

                <div class="social_media">
                    <ul>
                        <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>

        <?php
        if (isset($_SESSION["id_insegnante"])) {
            echo '<div class="subjects">';
            echo '<form action="user.php" method="post" class="materie" autocomplete="off">';
            echo '<input type="hidden" name="tipo" value="elimina">';
            echo '<table border="0" class="tableclass">';
            echo '<thead class="table_head">';
            echo '<tr class="table_title">';
            echo '<th class="space"></th>';
            echo '<th class="title">Materie che insegni</th>';
            echo '</tr>';
            echo '</thead>';
            echo '<tbody class="table_body">';

            $selectMaterie = 'SELECT m.id, m.nome';
            $selectMaterie .= ' FROM materie as m';
            $selectMaterie .= ' INNER JOIN insegnanti_materie as im';
            $selectMaterie .= ' ON m.id = im.id_materia';
            $selectMaterie .= ' INNER JOIN insegnanti as i';
            $selectMaterie .= ' ON im.id_insegnante = i.id';
            $selectMaterie .= ' WHERE i.id = ' . $_SESSION["id_insegnante"];
            $result = $conn->query($selectMaterie) or die($conn->error);
            while ($row = $result->fetch_assoc()) {
                echo '<tr class="table_row">';
                echo '<td class="table_checkbox">';
                echo '<input type="checkbox" name="' . $row["id"] . '" id="materia">';
                echo '</td>';
                echo '<td class="table_label">';
                echo '<label for="materia">' . $row["nome"] . '</label>';
                echo '</td>';
                echo '</tr>';
            }
            echo '</tbody>';
            echo '</table>';
            echo '<div class="explanation">';
            echo '<p>Qua trovi elencate tutte le materie che hai detto di poter spiegare, se hai cambiato idea seleziona quelle che non vuoi più ripetere e poi clicca il bottone conferma.</p>';
            echo '<input type="submit" value="CONFERMA">';
            echo '</div>';
            echo '</form>';
            echo '</div>';
        }
        ?>
    </div>
    <script src="script/main2.js"></script>
</body>

</html>