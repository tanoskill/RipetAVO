<?php
session_start();
include "connection.php";

if(!empty($_POST["keyword"])) {
    $queryMaterie = 'SELECT m.nome';
	$queryMaterie .= ' FROM materie as m';
	$queryMaterie .= ' INNER JOIN materie_indirizzo as mi';
	$queryMaterie .= ' ON m.id = mi.id_materia';
	$queryMaterie .= ' INNER JOIN indirizzi as i';
	$queryMaterie .= ' ON mi.id_indirizzo = i.id';
	$queryMaterie .= ' WHERE i.id = "'.$_SESSION["indirizzo"].'"';
    $queryMaterie .= ' AND m.nome like "%'.$_POST["keyword"].'%" ORDER BY m.nome LIMIT 0,6';
	$result = $conn->query($queryMaterie) or die($conn->error);
    if(!empty($result)) {
?>
<ul id="autocomplete-list">
<?php
    foreach($result as $materia) {
?>
<li id="autocomplete__option" class="autocomplete__option" onClick="selectMaterie('<?php echo $materia["nome"]?>');"><?php echo $materia["nome"]; ?></li>
<?php 
    } 
?>
</ul>
<?php 
    } } 
?>