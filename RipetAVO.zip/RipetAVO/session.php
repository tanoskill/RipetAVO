<?php
    if (isset($_SESSION['login_time'])) {
        $time = $_SESSION['login_time'];
        $_SESSION['login_time'] = $_SERVER['REQUEST_TIME'];
        if (time() > ($time + 3600)) {
            session_unset();
            session_destroy();
            header("Location: index.php");
        }
    }
?>
