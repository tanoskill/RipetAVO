<?php
    session_start();
    include "connection.php";

    if(!empty($_POST["nome"])){ 

        $selectInsegnanti = 'SELECT i.id, s.nome, s.cognome, s.anno, s.sezione';
        $selectInsegnanti .= ' FROM studenti as s';
        $selectInsegnanti .= ' INNER JOIN insegnanti as i';
        $selectInsegnanti .= ' ON i.id_studente = s.id';
        $selectInsegnanti .= ' INNER JOIN insegnanti_materie as im';
        $selectInsegnanti .= ' ON i.id = im.id_insegnante';
        $selectInsegnanti .= ' INNER JOIN materie as m';
        $selectInsegnanti .= ' ON im.id_materia = m.id';
        $selectInsegnanti .= ' WHERE m.nome = "'.$_POST["nome"].'"';
        $selectInsegnanti .= ' AND s.id <> '.$_SESSION["id"];
        $selectInsegnanti .= ' GROUP BY s.id';
        $selectInsegnanti .= ' ORDER BY s.anno DESC';

        $result = $conn->query($selectInsegnanti) or die($conn->error);
        if($result->num_rows > 0){
            while ($row = $result->fetch_assoc()) {
                $str = $row["nome"]." ".$row["cognome"]." - ".$row["anno"]."".$row["sezione"];
                echo '<option name="insegnante" value="'.$row['id'].'">'.$str.'</option>';
            }
        }else{
            echo '<option value="">Nessun insegnante</option>'; 
        }
    }
?>

 
 


