<?php
    include "connection.php";
    $value = $_REQUEST['Field'];
    $str = explode(" ", $value);
    $text = $str[1];
    $flag = false;

    switch($str[0]){
        case "text": {
            $pattern = "/^[a-zèàòùì']+$/i";
            if (preg_match($pattern, $text)) {
                $flag = true;
            }
        }break;
        case "mail":{
            $pattern = "/^[a-zA-Z0-9_.+-]+@(?:(?:[a-zA-Z0-9-]+\.)?[a-zA-Z]+\.)?(studenti.itisavogadro)\.it$/m";
            if(preg_match($pattern, $text)) {
                $flag = true;
            }

            $sql = "SELECT email FROM studenti WHERE email = '".$text."' ";
            $result = mysqli_query($conn,$sql);
            while($row = mysqli_fetch_array($result)){

                if($row["email"] == $text){
                    $flag = false;
                }else{
                    $flag = true;
                }
            }
            
            mysqli_close($conn);
        }break;
        case "pass":{
            $pattern ="/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[.#?!@$%^&*-]).{8,}$/m";
            if(preg_match($pattern, $text)) {
                $flag = true;
            }
        }break;
        case "clss":{
            $pattern = "/^([1-5])([a-nA-N])$/m";
            if(preg_match($pattern, $text)) {
                $flag = true;
            }
        }break;
    }

    if($flag == false){
        echo false;
    }else{
        echo true;
    }
?>
