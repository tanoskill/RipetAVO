const sign_in_btn = document.querySelector("#sign-in-btn");
const sign_up_btn = document.querySelector("#sign-up-btn");
const container = document.querySelector(".container");
const titolo = document.querySelector(".signup");

sign_up_btn.addEventListener("click", () => {
  container.classList.add("sign-up-mode");
  setTimeout(() => {
    titolo.classList.add("show");
  }, 1000);
});

sign_in_btn.addEventListener("click", () => {
  container.classList.remove("sign-up-mode");
  setTimeout(() => {
    titolo.classList.remove("show");
  }, 1000);
});

function checkField(value, iconC, tag1, tag2) {
  let div = document.querySelector(tag1);
  let icon = document.querySelector(tag2);
  var value1 = value.substring(5, `${value.length}`);
  if (value1 == '') {
    div.style.borderColor = "transparent";
    if (icon.classList.contains("fa-check")) {
      icon.classList.remove("fa-check");
    }
    if (icon.classList.contains("fa-times")) {
      icon.classList.remove("fa-times");
    }
    icon.classList.add(iconC);
    icon.style.color = "#CACACA";
  } else {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
      if (this.readyState == 4 && this.status == 200) {
        if (this.responseText == false) {
          div.style.borderColor = "red";

          if (icon.classList.contains(iconC)) {
            icon.classList.remove(iconC);
          }
          if (icon.classList.contains("fa-check")) {
            icon.classList.remove("fa-check");
          }

          icon.classList.add("fa-times");
          icon.style.color = "red";

          controlloE = true;
        } else {
          div.style.borderColor = "#0066CC";

          if (icon.classList.contains(iconC)) {
            icon.classList.remove(iconC);
          }
          if (icon.classList.contains("fa-times")) {
            icon.classList.remove("fa-times");
          }

          icon.classList.add("fa-check");
          icon.style.color = "#0066CC";
          controlloE = false;
        }
        lastCheck();
      }
    };
    xmlhttp.open("POST", "checkText.php?Field=" + value, true);
    xmlhttp.send();
  }
}

function checkIndirizzo(select) {
  let bottone = document.getElementById("button");
  if (select == "") {
    bottone.disabled = true;
  } else {
    bottone.disabled = false;
  }
}

function lastCheck() {
  let bottone = document.getElementById("button");
  let name = document.querySelector("[nome1]");
  let surname = document.querySelector("[cognome1]");
  let mail = document.querySelector("[mail1]");
  let password = document.querySelector("[password1]");
  let classe = document.querySelector("[classe1]");

  var blu = "rgb(0, 102, 204)";

  if (name.style.borderColor == blu &&
    surname.style.borderColor == blu &&
    mail.style.borderColor == blu &&
    password.style.borderColor == blu &&
    classe.style.borderColor == blu) {

    bottone.disabled = false;
  } else {
    bottone.disabled = true;
  }
}

function swap(){
  let div1 = document.querySelector("[div1]").classList;
  let div2 = document.querySelector("[div2]").classList;

  if (div1.contains("hide")) {
    div1.remove("hide");
    div2.add("hide");
  } else {
    div2.remove("hide");
    div1.add("hide");
  }
}