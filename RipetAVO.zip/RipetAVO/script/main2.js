window.onload = swapButton();

function swapButton(){
    let button = document.querySelector("[button]").classList;
    if(button.contains("hide")) {
        button.remove("hide");
    }else{
        button.add("hide");
    }
}